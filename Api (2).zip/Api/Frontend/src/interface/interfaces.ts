interface IPersona{
    name: string;
    lastName: string;
    age: number;
}
const empleado:IPersona ={ //SE CREA UN OBJETO CUANDO NO TIENE METODOS
    name: "SEBASTIAN",
    lastName: "Gonzalez",
    age: 21
}
console.log(empleado)