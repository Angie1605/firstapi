create database API;

create table users(
    id serial primary key, 
    name varchar(40),
    email varchar(300)

 
);

insert into users (name,email) values
('Danna', 'dannagabi09@gmail.com'),
('Alexandra', 'alexacalderon09@hotmail.com');